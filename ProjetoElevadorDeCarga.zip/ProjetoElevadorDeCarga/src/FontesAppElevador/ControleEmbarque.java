package FontesAppElevador;

public class ControleEmbarque {

	public boolean embarcar(Pessoa pessoa, Elevador elevador) {
	
		double pesoFinalElevador = elevador.entrarNoelevador(pessoa.getPeso());
		
		boolean alarmeAcesso = elevador.avaliarpeso(pesoFinalElevador);
		if (alarmeAcesso == false) {
			return true;
		}
		else {
			return false;
		}
	}
}