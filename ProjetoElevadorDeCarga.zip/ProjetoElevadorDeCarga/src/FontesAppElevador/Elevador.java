package FontesAppElevador;

public class Elevador {
	
	int id;
	double cargaMaxima;
	double cargaAtual;
	boolean sinalAlerta;
	
	//Getters & Setters
	public void setId(int valor) {
		this.id = valor;
	}
	
	public double getId() {
		return this.id;
	}
	
	public void setCargaMaxima(double valor) {
		this.cargaMaxima = valor;
	}
	
	public double getCargaMaxima() {
		return this.cargaMaxima;
	}
	
	public void setCargaAtual(double valor) {
		this.cargaAtual = valor;
	}
	
	public double getCargaAtual() {
		return this.cargaAtual;
	}
	
	public void setSinalAlerta(boolean valor) {
		this.sinalAlerta = valor;
	}
	
	public boolean getSinalAlerta() {
		return this.sinalAlerta;
	}
	
	public double entrarNoelevador(double peso) {
		Calculadora calc = new Calculadora();
		this.cargaAtual = calc.somar(this.cargaAtual, peso);
		return this.cargaAtual;
	}
	
	public double sairDoelevador(double peso) {
		Calculadora calc = new Calculadora();	
		this.cargaAtual = calc.subtrair(this.cargaAtual, peso);
		return cargaAtual;
	}
	
	public boolean avaliarpeso(double pesoElevador) {
		if(pesoElevador > this.cargaMaxima) {
			return sinalAlerta = true;
		}
		else {
			return sinalAlerta = false;
		}
	}
}