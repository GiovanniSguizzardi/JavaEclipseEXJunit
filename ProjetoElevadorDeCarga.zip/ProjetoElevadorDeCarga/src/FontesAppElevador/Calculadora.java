package FontesAppElevador;

public class Calculadora {

	double resultado;
	
	//Getters e Setters
	public void setResultado(double valor) {
		this.resultado = valor;
	}
	
	public double getResultado() {
		return this.resultado;
	}
	
	//Método de soma
	public double somar(double valor1, double valor2) {
		this.resultado = valor1 + valor2;
		return this.resultado;
	}
	
	//Método de subtração
	public double subtrair(double valor1, double valor2) {
		this.resultado = valor1 - valor2;
		return this.resultado;
	}
}